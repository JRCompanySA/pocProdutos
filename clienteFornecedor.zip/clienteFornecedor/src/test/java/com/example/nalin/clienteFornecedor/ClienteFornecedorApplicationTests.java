package com.example.nalin.clienteFornecedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteFornecedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
