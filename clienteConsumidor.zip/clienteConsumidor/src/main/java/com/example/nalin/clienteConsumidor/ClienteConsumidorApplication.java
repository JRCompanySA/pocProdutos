package com.example.nalin.clienteConsumidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteConsumidorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteConsumidorApplication.class, args);
	}

}
