package com.example.nalin.clienteConsumidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteConsumidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
